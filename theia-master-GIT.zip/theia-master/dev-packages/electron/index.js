module.exports = require('electron');
