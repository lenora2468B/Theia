import Electron = require('electron');
export = Electron;
