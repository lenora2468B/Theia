---
name: Bug Report
about: Create a report to help us improve
---

<!-- Please provide a detailed description of the bug. -->
### Bug Description:

<!-- Please provide clear steps to reproduce the bug. -->
### Steps to Reproduce:

1.
2.
3.

<!-- Please provide any additional information available. -->
<!-- Additional information can be in the form of logs, screenshots, screencasts. -->

### Additional Information

- Operating System:
- Theia Version:
