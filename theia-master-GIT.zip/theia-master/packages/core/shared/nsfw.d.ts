import nsfw = require('nsfw');
export = nsfw;
