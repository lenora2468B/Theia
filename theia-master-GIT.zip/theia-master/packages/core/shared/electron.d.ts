import Electron = require('@theia/electron');
export = Electron;
