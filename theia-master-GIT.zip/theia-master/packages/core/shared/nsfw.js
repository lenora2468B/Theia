module.exports = require('nsfw');
