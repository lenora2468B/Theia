import WebSocket = require('ws');
export = WebSocket;
