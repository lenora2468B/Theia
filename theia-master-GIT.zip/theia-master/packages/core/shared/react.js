module.exports = require('react');
