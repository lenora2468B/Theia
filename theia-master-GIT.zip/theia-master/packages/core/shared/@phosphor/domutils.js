module.exports = require('@phosphor/domutils');
