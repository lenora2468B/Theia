module.exports = require('@phosphor/properties');
