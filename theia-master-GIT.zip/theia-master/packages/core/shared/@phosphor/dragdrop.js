module.exports = require('@phosphor/dragdrop');
