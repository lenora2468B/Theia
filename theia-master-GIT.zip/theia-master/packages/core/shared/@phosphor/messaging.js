module.exports = require('@phosphor/messaging');
