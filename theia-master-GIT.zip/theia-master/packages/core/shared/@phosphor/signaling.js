module.exports = require('@phosphor/signaling');
