module.exports = require('@phosphor/virtualdom');
