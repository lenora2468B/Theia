module.exports = require('@phosphor/commands');
