module.exports = require('fuzzy');
