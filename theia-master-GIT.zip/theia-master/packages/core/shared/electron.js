module.exports = require('@theia/electron');
