module.exports = require('react-dom');
